package com.alumnidb.impl;

import com.alumnidb.dao.AlumniDao;
import com.alumnidb.dao.CommitteeDao;
import com.alumnidb.dao.EventDao;
import com.alumnidb.entity.Alumni;
import com.alumnidb.entity.Event;
import com.alumnidb.service.EventService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class EventServiceImpl implements EventService {
    private EventDao eventDao;
    private CommitteeDao committeeDao;
    private AlumniDao alumniDao;

    public EventServiceImpl(EventDao eventDao, CommitteeDao committeeDao, AlumniDao alumniDao) {
        this.eventDao = eventDao;
        this.committeeDao = committeeDao;
        this.alumniDao = alumniDao;
    }

    @Override
    public Event loadEventById(Long eventId) {
        return eventDao.findById(eventId).orElseThrow(() -> new EntityNotFoundException("Event with id " + eventId + " not found"));
    }

    @Override
    public Event createEvent(String eventName, String eventDuration, String eventDescription) {
        Event event = new Event();
        event.setName(eventName);
        event.setDuration(eventDuration);
        event.setDescription(eventDescription);
        return eventDao.save(event);
    }

    @Override
    public Event createOrUpdateEvent(Event event) {
        return eventDao.save(event);
    }

    @Override
    public List<Event> findEventsByNameContaining(String keyword) {
        return eventDao.findByNameContaining(keyword);
    }

    @Override
    public List<Event> findAllEvents() {
        return eventDao.findAll();
    }


    @Override
    public Event updateEvent(Event event) {
        return eventDao.save(event);
    }

    @Override
    public List<Event> fetchEventForAlumni(Long alumniId) {
        Alumni alumni = alumniDao.findById(alumniId).orElseThrow(() -> new EntityNotFoundException("Alumni with id " + alumniId + " not found"));
        return new ArrayList<>(alumni.getAttendedEvents());
    }


    @Override
    public void deleteEvent(Long eventId) {
        eventDao.deleteById(eventId);
    }


    @Override
    public void assignAlumniToEvent(Long eventId, Long alumniId) {
        Alumni alumni = alumniDao.findById(alumniId).orElseThrow(() -> new EntityNotFoundException("Alumni with id " + alumniId + " not found"));
        Event event = eventDao.findById(eventId).orElseThrow(() -> new EntityNotFoundException("Event with id " + eventId + " not found"));
        event.addAlumni(alumni);
        eventDao.save(event);
    }
}
