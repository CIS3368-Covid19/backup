package com.alumnidb.entity;

import java.time.LocalDateTime;
import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "events")
public class Event {

    @Id


    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_id")
    private long eventId;

    @Column(name = "name", length = 100, nullable = false)
    private String name;

    @Column(name = "description", length = 500, nullable = false)
    private String description;
    @Column(name = "duration", nullable = false)
    private String duration;
    @Column(name = "start_date", nullable = false)
    private LocalDateTime startDate;

    @Column(name = "end_date", nullable = false)
    private LocalDateTime endDate;

    @ManyToMany(mappedBy = "attendedEvents", fetch = FetchType.LAZY)
    private Set<Alumni> alumniSet = new HashSet<>();

    @ManyToMany(mappedBy = "events")
    private Set<Committee> committees = new HashSet<>();

    public Event() {
    }

    public Event(String name, LocalDateTime startDate, LocalDateTime endDate, String description, Committee committee) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.description = description;

    }

    public Long getEventId() {
        return eventId;
    }

    public void setEventId(Long eventId) {
        this.eventId = eventId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public Set<Alumni> getAlumniSet() {
        return alumniSet;
    }

    public void setAlumniSet(Set<Alumni> alumniSet) {
        this.alumniSet = alumniSet;
    }

    public void addAlumni(Alumni alumni) {
        this.alumniSet.add(alumni);
        alumni.getAttendedEvents().add(this);
    }

    public void removeAlumniFromEvent(Alumni alumni) {
        this.alumniSet.remove(alumni);
        alumni.getEvents().remove(this);
    }

    public Set<User> getUsers() {
        Set<User> users = new HashSet<>();
        for (Alumni alumni : alumniSet) {
            User user = alumni.getUser();
            if (user != null) {
                users.add(user);
            }
        }
        return users;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public Set<Committee> getCommittees() {
        return committees;
    }

}

