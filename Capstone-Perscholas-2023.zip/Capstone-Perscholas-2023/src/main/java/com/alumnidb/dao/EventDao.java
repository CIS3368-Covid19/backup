package com.alumnidb.dao;

import com.alumnidb.entity.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EventDao extends JpaRepository<Event, Long> {
    List<Event> findByNameContaining(String keyword);

    @Query("SELECT e FROM Event e WHERE e.eventId IN (SELECT ee.eventId FROM e.alumniSet ee WHERE ee.alumniId = :alumniId)")
    List<Event> getEventByAlumniId(Long alumniId);
}
