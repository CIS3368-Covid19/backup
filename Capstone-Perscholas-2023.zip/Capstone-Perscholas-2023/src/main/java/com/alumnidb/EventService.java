package com.alumnidb;

import com.alumnidb.dao.CommitteeDao;
import com.alumnidb.entity.Committee;
import com.alumnidb.dao.AlumniDao;
import com.alumnidb.dao.EventDao;
import com.alumnidb.entity.Event;
import com.alumnidb.service.EventService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EventServiceImplTest {

    @Mock
    private EventDao eventDao;

    @Mock
    private CommitteeDao committeeDao;

    @Mock
    private AlumniDao alumniDao;

    @InjectMocks
    private EventServiceImpl eventService;

    @Test
    void testLoadEventById() {
        Event event = new Event();
        event.setEventId(1L);

        when(eventDao.findById(any())).thenReturn(Optional.of(event));

        Event actualEvent = eventService.loadEventById(1L);

        assertEquals(event, actualEvent);
    }

    @Test
    void testExceptionForNotFoundEventById() {
        when(eventDao.findById(any())).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, ()->eventService.loadEventById(2L));
    }

    @Test
    void testCreateEvent() {
        Committee committee = new Committee();
        committee.setCommitteeId(1L);

        when(committeeDao.findById(any())).thenReturn(Optional.of(committee));

        eventService.createEvent("Spring Boot Conference", "2022-10-01", "10:00:00", "17:00:00", "Online", 1L);

        verify(eventDao).save(any());
    }

    @Test
    void testCreateOrUpdateEvent() {
        Event event = new Event();
        event.setEventId(1L);

        eventService.createOrUpdateEvent(event);

        ArgumentCaptor<Event> argumentCaptor = ArgumentCaptor.forClass(Event.class);

        verify(eventDao).save(argumentCaptor.capture());

        Event capturedValue = argumentCaptor.getValue();

        assertEquals(event, capturedValue);
    }

    @Test
    void testFindEventsByEventName() {
        String eventName = "Spring Boot";
        eventService.findEventsByEventName(eventName);

        verify(eventDao).findEventsByEventNameContains(eventName);
    }

    @Test
    void testFetchAll() {
        List<Event> events = List.of(new Event(), new Event(), new Event());
        when(eventDao.findAll()).thenReturn(events);

        List<Event> actualEvents = eventService.fetchAll();

        assertEquals(events, actualEvents);
    }

    @Test
    void testFetchEventForAlumni() {
        List<Event> events = List.of(new Event(), new Event());
        when(eventDao.getEventByAlumniId(1L)).thenReturn(events);

        List<Event> actualEvents = eventService.fetchEventForAlumni(1L);

        assertEquals(events, actualEvents);
    }

    @Test
    void testRemoveEvent() {
        eventService.removeEvent(1L);
        verify(eventDao).deleteById(1L);
    }
}
