Old Penang Free School Alumni Database Management System 


Objective
The aim of this project is to build a working model that will be able to manage alumni data of Old Penang Free School Alumni and provide easy access to all members. It will features a Landing Page. Login page for Admin and Alumnus, Register page, Event Management page.

Users can login with their username and password and new users may register by clicking the register button. Once logged in, you are directed to the Home Page. The Home Page contains a Search Tab, ‘Update Profile’ Tab and an ‘About’ Tab. The Alumni may search for users from the database based on their names.

This java project uses JDBC connectivity and Java server pages for the front end and mySQL database server for the back end.

Some of the feature that that the OPFS ADMS will contain:

1. Contact Information: Collect and store the alumni's contact information, such as name, email address, phone number, physical address, and any other relevant details.

2. Employment Information: Section for employment information, including the alumni's job title, company name, and industry.

3. Graduation History: Section for graduation year.

4. Networking (Forum): Search for fellow alumni, and share updates and news.

5. Donations: Track alumni donations and giving history.

6. Events: Promotion and management of alumni events, including reunions, career fairs, and other networking opportunities.

7. Privacy and Security: The privacy and security of members data will comply with relevant data protection regulations.

8. Integration: Integrating with other software or 3rd party services such as social media platforms, email marketing, and fundraising software.

9. User-friendly Interface: The program should have an easy-to-use interface that is accessible to all alumni, regardless of their technical ability.
#   b a c k u p  
 